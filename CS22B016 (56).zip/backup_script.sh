#!/bin/bash

START_TIME=$(date +%s%3N)
while getopts ":s:d:o:" opt; do
	case $opt in
	s)SOURCE_DIR="$OPTARG";;
	d)DEST_DIR="$OPTARG";;
	o)OUTPUT_FILE="$OPTARG";;
	*) exit 1 ;;
	esac
done 

if [ -z "$SOURCE_DIR" ] || [ -z "$DEST_DIR" ] || [ -z "$OUTPUT_FILE" ]; then
	exit 1
fi

SCRIPT_PATH="$(realpath "$0")"

mkdir -p "$(dirname "$OUTPUT_FILE")"

if [ ! -f "$OUTPUT_FILE" ]; then 
	
	echo "PID","RUNTIME","Number of files copied" > "$OUTPUT_FILE"
fi

#echo "$SCRIPT_PATH"
CRON_JOB="0 0 * * * $SCRIPT_PATH -s $SOURCE_DIR -d $DEST_DIR -o $OUTPUT_FILE"



add_cron_job(){
	(crontab -l 2>/dev/null | grep -F "$CRON_JOB") || (
		(crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
	)
}

add_cron_job

PID=$$


count=0
IFS=$'\n'

#find "$SOURCE_DIR" -type f -name '*[AEIOUaeiou]*' | while  read -r file; do

for file in $(find "$SOURCE_DIR" -type f -name '*[AEIOUaeiou]*') ; do

	RELATIVE_PATH=$(realpath --relative-to="$SOURCE_DIR" "$file" )
	DEST_FILE="$DEST_DIR/$RELATIVE_PATH"
	#echo "$DEST_FILE"
	if [ ! -f "$DEST_FILE" ] || [ "$file" -nt "$DEST_FILE"  ]; then
	
		mkdir -p "$(dirname "$DEST_FILE")"
		cp  "$file" "$DEST_FILE"
		count=$((count+1))
	fi
	
done

END_TIME=$(date +%s%3N)
RUNTIME=$((END_TIME-START_TIME))
echo "$PID","$RUNTIME","$count" >> "$OUTPUT_FILE"


