# Automated File Transfer and Logging Script

## Overview

The script backs up files containing vowels in their names from a specified source directory to a destination directory. It also keeps track of the process details—such as the Process ID (PID), runtime, and the number of files copied—to an output file. The script includes a function to schedule itself as a daily cron job. This can also be done manually by the following process. Open crontab in the editor and add 0 0 * * * "command" to crontab
```bash
crontab -e
->add to crontab
0 0 * * * path/to/backup_script.sh -s /path/to/source -d /path/to/destination -o /path/to/output.csv
```


## Working

- Use the find function along with the pattern for particular file name and use newer than to determine the files to be copied. Options used for arguments to the script. (The headers for output files are created only if the output file doesn't already exist in the path given. Headers are added while making the output file. Hence if it already exists need to put the appropriate headers.)

## Usage

To execute the script, you need to provide the following options:

- `-s` : Source directory (the directory to scan for files).
- `-d` : Destination directory (the directory where files will be copied).
- `-o` : Output file (the file where the log will be stored).

### Example Command

```bash
./backup_script.sh -s /path/to/source -d /path/to/destination -o /path/to/output.csv
