#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#define NUM_ACCESSES 1000 // Number of random accesses per file

void measure_random_access(const char *filename) {
   
    int fd = open(filename, O_RDONLY);
    if (fd == -1) {
        perror("Failed to open file");
        return;
    }

    
    off_t file_size = lseek(fd, 0, SEEK_END); 
    if (file_size == -1) {
        perror("Failed to get file size");
        close(fd);
        return;
    }

    if (file_size == 0) {
        printf("File '%s' is empty, skipping random access.\n", filename);
        close(fd);
        return;
    }

    lseek(fd, 0, SEEK_SET);

    clock_t start = clock();  

    for (int i = 0; i < NUM_ACCESSES; i++) {
        off_t random_pos = rand() % file_size;  
        lseek(fd, random_pos, SEEK_SET);  
        char byte;
        read(fd, &byte, sizeof(char));  
    }

    clock_t end = clock(); 
    double time_taken = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("Random access time for file '%s': %f seconds\n", filename, time_taken);

    close(fd);  
}

int main() {
    srand(time(NULL));  
    measure_random_access("file_of_10KB");
    measure_random_access("file_of_10MB.txt");
    measure_random_access("file_of_1GB");

    return 0;
}

