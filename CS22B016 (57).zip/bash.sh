sum=0
for file in cons_*.txt; do
  last_line=$(tail -n 1 "$file")
  sum=$(echo "$sum + $last_line" | bc)
done
echo $sum

cat prod_*.txt | grep '[aeiou]' | wc  -l
