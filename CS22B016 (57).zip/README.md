# Producer-Consumer System with IPC



## Overview

This project implements a Producer-Consumer system using Inter-Process Communication (IPC) and threads in C. The producer generates random characters, and the consumer processes them to count vowels. The program supports the following configurations:



1. **Single Producer, Single Consumer**

2. **Single Producer, Multiple Consumers**

3. **Multiple Producers, Multiple Consumers**



Consumers log their outputs every minute to separate files.
Debug print statements to verify present as well.
Mutex used for global variables. Adding things to pipe and reading all with threads.

Producers: Each producer generates a stream of random lowercase characters ( 1 million per minute). Waits for minute to get over. Every minute, they write the produced characters into a prod_<id>.txt file. Vowels are counted and shared between producers using a global counter.

Consumers: Each consumer reads characters from a shared pipe, counting the number of vowels. Every minute, they write the count into cons_<id>.txt. The consumers stop once all producers have finished producing characters, indicated by a special termination signal ('!').

Synchronization: Pipes are used for IPC, and mutexes ensure thread-safe access to shared resources like the pipe, vowel counts, and termination conditions.

For bonus unshare() is used. The required header files were added. These processes are created in separate namespaces using the unshare system call with the flags CLONE_NEWNET and CLONE_NEWIPC. The namespaces isolate the network and IPC resources between the processes.

To handle communication between the Producer and Consumer, we use pipes. These processes are created in separate namespaces using the unshare system call with the flags CLONE_NEWNET and CLONE_NEWIPC. The namespaces isolate the network and IPC resources between the processes.

To handle communication between the Producer and Consumer, we use pipes. Run in root directory using sudo.


## Subproblems



### 1. Single Producer, Single Consumer

- One producer generates random characters, and one consumer reads them and counts vowels.

- Uses a single pipe for communication.



### 2. Single Producer, Multiple Consumers

- One producer generates characters, and five consumers read and count vowels.

- Single pipe used for shared communication.



### 3. Multiple Producers, Multiple Consumers

- Five producers generate characters, and five consumers read and count vowels.

- Single pipe is shared for all communication.



## How to Compile



- **Compile all subproblems**:

  

```bash
  make q_1

  make q_2

  make q_3

  ./q_3

  sudo ./bonus



 