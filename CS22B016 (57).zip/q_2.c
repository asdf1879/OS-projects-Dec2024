#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

int pipes[2]; 
pthread_mutex_t pipe_mutex;

#define MAXLIMIT 1000000


int num_end_produced;
pthread_mutex_t endcond;

int total_vowels_prod;

int total_vowels_read;
pthread_mutex_t vc;

void *producer(void *arg) {
    char ch;
    srand(time(NULL));
    int char_produced = 0;
    time_t stime = time(NULL);

    int x = 5;
    FILE *file = fopen("prod_1.txt", "a");
   // FILE *filetest = fopen("prod_1test.txt", "a");
    char buffer[1000001];

    while (x--) {
        int buffer_ptr = 0;
        while (time(NULL) - stime < 60) {
            ch = ('a' + rand() % 26);
            buffer[buffer_ptr++] = ch;
            char_produced++;
            if (ch == 'a' || ch== 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                total_vowels_prod++;
            }

        
            write(pipes[1], &ch, 1);

            //fprintf(filetest, "%c", ch);
            if (char_produced == MAXLIMIT) {
                while (time(NULL) - stime < 60); // Wait for the minute to pass
                break;
            }
        }
        printf("Produced %d characters\n", char_produced);
        for (int i = 0; i < buffer_ptr; i++) {
            fprintf(file, "%c\n", buffer[i]);
        }
        stime = time(NULL);
        char_produced = 0;
    }
    ch='!';
    pthread_mutex_lock(&pipe_mutex);
    write(pipes[1], &ch, 1);
    pthread_mutex_unlock(&pipe_mutex);


    fclose(file);
    //fclose(filetest);
    return NULL;
}

void *consumer(void *arg) {
    char c;
    int vowels = 0;
    int count = 0;
    int cons_id = *((int *)arg);
    char filename[] = "cons_e.txt";
    filename[5] = (char)(cons_id + '0');
    FILE *fp = fopen(filename, "a");
    time_t stime = time(NULL);
    int last_vowel_count = vowels;
    
    while (1) {
        pthread_mutex_lock(&pipe_mutex);
        int st = read(pipes[0], &c, 1);
        pthread_mutex_unlock(&pipe_mutex);

        
        if(st==0){
            pthread_mutex_lock(&endcond);
            if(num_end_produced==1){
                pthread_mutex_unlock(&endcond);
                break;
            }
            pthread_mutex_unlock(&endcond);   
        }
        else if (st < 0) {
            fprintf(stderr, "Read error\n");
            return 0;
        } 
        else {
            count++;
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                vowels++;

                pthread_mutex_lock(&vc);
                total_vowels_read++;
                pthread_mutex_unlock(&vc);
            }
            if(c=='!'){
                pthread_mutex_lock(&endcond);
                num_end_produced++;
                pthread_mutex_unlock(&endcond);
            }


            if (time(NULL) - stime >= 60) {
                fprintf(fp, "%d\n", vowels);
                fflush(fp);
                last_vowel_count = vowels;
                stime = time(NULL);
            }
        }
        pthread_mutex_lock(&endcond);
        if(num_end_produced==1){
            pthread_mutex_unlock(&endcond);
            break;
        }
        pthread_mutex_unlock(&endcond);
    }

    if (vowels != last_vowel_count) {
        fprintf(fp, "%d\n", vowels);
    }
    
    fclose(fp);
    printf("Chars read = %d by consumer %d\n", count, cons_id);
    return NULL;
}

int main() {
    pthread_t producer_thread;
    pthread_t consumer_threads[5];
    pthread_mutex_init(&pipe_mutex, NULL);

    pthread_mutex_init(&endcond,NULL);
    
    pthread_mutex_init(&vc,NULL);
    time_t code_start=time(NULL);
    num_end_produced=0;
    total_vowels_prod=0;
    total_vowels_read=0;


    if (pipe(pipes) == -1) {
        fprintf(stderr, "Pipe creation failed\n");
        exit(1);
    }

    // Fork the producer process
    pid_t pid = fork();
    
    if (pid < 0) {
        fprintf(stderr, "Fork failed\n");
        return 1;
    }

    if (pid == 0) {
        // Producer process
        close(pipes[0]); // Close read-end for producer
        pthread_create(&producer_thread, NULL, producer, NULL);
        pthread_join(producer_thread, NULL);
        printf("Producer produced %d vowels \n" ,total_vowels_prod);
        return 0;
    }

    // Fork the consumer process
    if (pid > 0) {
        pid_t consumer_f = fork();
        if (consumer_f < 0) {
            fprintf(stderr, "Fork failed\n");
            return 1;
        }

        if (consumer_f == 0) {
            // Consumer process
            close(pipes[1]); // Close write-end for consumers

            int ids[5];
            for (int i = 0; i < 5; i++) {
                ids[i] = i + 1; 
                pthread_create(&consumer_threads[i], NULL, consumer, &ids[i]);
            }

            for (int i = 0; i < 5; i++) {
                pthread_join(consumer_threads[i], NULL);
            }
            printf("Consumer read/consumed %d vowels\n",total_vowels_read);
            return 0;
        }
    }

    close(pipes[0]);
    close(pipes[1]);

    wait(NULL);
    wait(NULL);

    printf("Producer and consumers finished\n");

    pthread_mutex_destroy(&pipe_mutex);
    return 0;
}
