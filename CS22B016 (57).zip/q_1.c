#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int pipes[2]; 
pthread_mutex_t pipe_mutex;
int vowprod;
int vowcon;
#define MAXLIMIT 1000000

void * producer(void * arg){
    char ch;
    srand(time(NULL));
    int char_produced=0;
    time_t stime=time(NULL);

    int x=5;
    FILE * file=fopen("prod_1.txt","a");
    //FILE * filetest=fopen("prod_1test.txt","a");
    char buffer[1000001];
    while(x--){
        int ptr=0;
        while(time(NULL)-stime<60){
            ch=('a'+rand()%26);
            buffer[ptr++]=ch;
            char_produced++;
            if (ch== 'a' || ch== 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                vowprod++;
            }
            write(pipes[1],&ch,1);

            //fprintf(filetest,"%c",ch);
            if(char_produced==MAXLIMIT){
                while(time(NULL)-stime<60);
                break;
            }
        }
        printf("%d\n",char_produced);
        for(int i=0;i<ptr;i++){
            fprintf(file,"%c\n",buffer[i]);
        }
        stime=time(NULL);
        char_produced=0;
    }
    
}

void * consumer(void * arg){
    char c;
    int vowels=0;
    int count=0;
    int vowcon=0;
    FILE *fp = fopen("cons_1.txt", "a");
    time_t stime=time(NULL);
    int last=vowels;
    while(read(pipes[0],&c,1)>0){
        count++;
        if (c== 'a' || c== 'e' || c == 'i' || c == 'o' || c == 'u') {
            vowels++;
            vowcon++;
        }
        if(stime-time(NULL)>=60){
            fprintf(fp,"%d",vowels);
            last=vowels;
            stime=time(NULL);
        }
    }
    if(vowels!=last){
        fprintf(fp,"%d",vowels);
    }
    //printf("Consumer: Read and processed 1 million characters in minute %d. Vowel count: %d\n", minute + 1, vowel_count);

        // Write to file the vowel count at the end of each minute
        
        //fprintf(fp, "Minute %d: Vowel count = %d\n", minute + 1, vowel_count);
        fclose(fp);
        printf("chars read= %d", count);
}


int main(){
    //0 read  //1 write
    pthread_t producer_thread;
    pthread_t consumer_thread;
    pthread_mutex_init(&pipe_mutex,NULL);

    if(pipe(pipes)==-1){
        fprintf(stderr,"pipe not created");
        exit(1);
    }
    // Fork the first child process
    pid_t pid = fork();
    
    if (pid < 0) {
        // Fork failed
        fprintf(stderr,"failed to create\n");
        return 1;
    }

    if (pid == 0) {
        // Inside the first child process
        close(pipes[0]);
        pthread_create(&producer_thread, NULL, producer, NULL);
        pthread_join(producer_thread, NULL);



        printf("vowel cre %d\n",vowprod);
        return 0;
    }

    // Fork the second child process
    
    if(pid!=0){
        pid_t consumer_f;
        consumer_f = fork();
        if (consumer_f < 0) {
            // Fork failed
            fprintf(stderr,"failed to create\n");   
            return 1;
        }

        if (consumer_f == 0) {
            // Inside the second child process
            close(pipes[1]);
            pthread_create(&consumer_thread, NULL, consumer, NULL);
            pthread_join(consumer_thread, NULL); 
            printf("%d",vowcon);
            return 0;  // Exit child process
        }
    }

    
    close(pipes[0]);
    close(pipes[1]);
    // Inside the parent process
    // Wait for both child processes to complete
    wait(NULL);
    wait(NULL);

    printf("done");

    return 0;
}