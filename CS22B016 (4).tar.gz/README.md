# Page Replacement System Simulation

This project implements a page replacement system in a simulated virtual memory environment with two page replacement policies: **Least Recently Used (LRU)** and **First In, First Out (FIFO)**. It simulates swapping between main memory and virtual memory, following page replacement policies to manage memory access and handle invalid addresses.

## Project Structure

- `make`: Compile the entire project.
- `make lru`: Compile the LRU page replacement policy.
- `make fifo`: Compile the FIFO page replacement policy.
- `fifo`: Run the FIFO-based page replacement simulation.
- `lru`: Run the LRU-based page replacement simulation.

## Command-line Options

Both `fifo` and `lru` accept the following options:

- `-M`: Specifies the maximum number of frames in main memory.
- `-V`: Specifies the maximum number of frames in virtual memory.
- `-P`: Specifies the page size.
- `-i`: Specifies the input file containing the processes and instructions.
- `-o`: Specifies the output file where the results will be written.

## Assumptions

- **Registers and pages**: We assume that registers are present and do not require all pages of a process to be present in memory simultaneously.
- **Error handling**: If an invalid address is encountered, the process stops running. Data stored is not nullified even after a process is killed.
- **Swapping on replacement**: When a page is replaced in memory, its content is swapped to virtual memory, even if the page is freed.
- **Graceful exit**: The simulation exits gracefully when errors or invalidities occur.

## Key Data Structures

### Page Tables

- `map<int, pair<int, int>> page_table_main_memory`: Maps frame numbers to process ID (PID) and page number in main memory.
- `map<int, pair<int, int>> page_table_virtual_memory`: Maps frame numbers to PID and page number in virtual memory.
- `map<pair<int, int>, int> rev_page_table_main_memory`: Maps PID and page number to frame number in main memory.
- `map<pair<int, int>, int> rev_page_table_virtual_memory`: Maps PID and page number to frame number in virtual memory.

### Free Slots

- `set<int> free_slots_main_memory`: Tracks free slots in main memory.
- `set<int> free_slots_virtual_memory`: Tracks free slots in virtual memory.

### Offset to Value Maps

- `map<int, map<int, int>> offset_to_value_main`: Maps offsets to values for each page in main memory.
- `map<int, map<int, int>> offset_to_value_virtual`: Maps offsets to values for each page in virtual memory.

### Process Instruction Storage

- `map<int, vector<string>> id_to_instructions`: Stores the instructions for each process by PID.

### Valid Process IDs

- `set<int> valid_pids`: Stores valid process IDs for tracking active processes.

### Replacement Structures

#### FIFO:

- `queue<Page*>` for managing the order of page accesses.

#### LRU:

- `DLL<Page*>` (Doubly Linked List) to track the least recently used pages.

### Frame to Page Mapping

- `map<int, Page*> frame_no_to_page`: Maps frame number to Page object in main memory.
- `map<int, Page*> virtual_frame_no_to_page`: Maps frame number to Page object in virtual memory.

## Page Replacement Policies

### LRU (Least Recently Used)

Once a page is accessed, it is moved to the end of the Doubly Linked List (DLL), which may involve removing the first element if the list exceeds the memory capacity.

### FIFO (First In, First Out)

Pages are removed in the order they were added. The first page is removed when memory is full, and new pages are added to the end of the queue.

## Error Handling

The system has been implemented to handle errors or invalid memory access gracefully. If an invalid address is encountered during execution, the process is stopped, and the program exits without crashing.

## How to Run

### Compile the project:

```bash
make
./lru -M <main_memory_frames> -V <virtual_memory_frames> -P <page_size> -i <input_file> -o <output_file>
./fifo -M <main_memory_frames> -V <virtual_memory_frames> -P <page_size> -i <input_file> -o <output_file>
