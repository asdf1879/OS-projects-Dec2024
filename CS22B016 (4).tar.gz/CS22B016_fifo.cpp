#include <bits/stdc++.h>
#include <unistd.h>

using namespace std;

int global_pid = 0;
int memory = 0;
int virtual_memory = 0;
int memory_size = 0;
int virtual_memory_size = 0;
int page_size = 0;
int no_of_virpages = 0;
int no_of_mempages = 0;
map<string, int> file_id;
map<int, string> id_file;

map<int, pair<int, int>> page_table_main_memory;    // stores frameno to pid and page no within the process
map<int, pair<int, int>> page_table_virtual_memory; // stores frameno to pid and page no within the process

map<pair<int, int>, int> rev_page_table_main_memory;    // stores pid and page no within the process to frameno
map<pair<int, int>, int> rev_page_table_virtual_memory; // stores pid and page no within the process to frameno

set<int> free_slots_main_memory;    // stores free slots in main memory
set<int> free_slots_virtual_memory; // stores free slots in virtual memory

map<int, map<int, int>> offset_to_value_main;    // stores offset to value for each page
map<int, map<int, int>> offset_to_value_virtual; // stores offset to value for each page

map<int, vector<string>> id_to_instructions; // stores instructions for each process id

set<int> valid_pids;

class Page
{
public:
    int pid;
    int where_is_it; // 0 for main memory, 1 for virtual memory
    int frame_no;
    int page_no;
    Page *next;
    Page *prev;

    Page(int pidarg, int where_is_itarg, int frame_noarg, int page_noarg)
    {
        pid = pidarg;
        where_is_it = where_is_itarg;
        frame_no = frame_noarg;
        page_no = page_noarg;
        next = NULL;
        prev = NULL;
    }
};

map<int, Page *> frame_no_to_page;         // stores frame no to Page obj
map<int, Page *> virtual_frame_no_to_page; // stores frame no to Page obj
queue<Page *> fifo_queue;                  // stores pages in fifo order

ifstream infile;
ofstream outfile;

void swap_to_main_memory(int which_page, int pid, int val, int addr, Page *page, int offset, int frame_no)
{
    if (free_slots_main_memory.size() > 0)
    {

        // check if free mem is available
        // update maps
        // update page vairables
        int frame_no = *free_slots_main_memory.begin();
        free_slots_main_memory.erase(free_slots_main_memory.begin());
        free_slots_virtual_memory.insert(page->frame_no);
        page_table_main_memory[frame_no] = {pid, which_page};
        rev_page_table_main_memory[{pid, which_page}] = frame_no;
        frame_no_to_page[frame_no] = page;
        virtual_frame_no_to_page.erase(page->frame_no);

        map<int, int> temp;
        temp = offset_to_value_main[frame_no];
        offset_to_value_main[frame_no] = offset_to_value_virtual[page->frame_no];
        offset_to_value_virtual.erase(page->frame_no);
        offset_to_value_virtual[page->frame_no] = temp;

        page->frame_no = frame_no;
        page->where_is_it = 0;

        memory += page_size;
        virtual_memory -= page_size;
        fifo_queue.push(page);
        // outfile<<"Page "<<which_page<<" of process "<<pid<<" is loaded into frame "<<frame_no<<" of main memory"<<endl;
    }
    else
    {
        // replace from queue
        Page *page_to_replace = fifo_queue.front();
        fifo_queue.pop();
        int frame_no_to_replace = page_to_replace->frame_no;
        page_table_main_memory.erase(frame_no_to_replace);
        rev_page_table_main_memory.erase({page_to_replace->pid, page_to_replace->page_no});
        frame_no_to_page.erase(frame_no_to_replace);

        page_table_main_memory[frame_no_to_replace] = {pid, which_page};
        rev_page_table_main_memory[{pid, which_page}] = frame_no_to_replace;
        frame_no_to_page[frame_no_to_replace] = page;

        map<int, int> temp;

        temp = offset_to_value_main[frame_no_to_replace];
        offset_to_value_main[frame_no_to_replace] = offset_to_value_virtual[page->frame_no];
        offset_to_value_virtual[page->frame_no] = temp;

        page_table_virtual_memory.erase(page->frame_no);
        rev_page_table_virtual_memory.erase({page->pid, page->page_no});
        virtual_frame_no_to_page.erase(page->frame_no);

        page_table_virtual_memory[page->frame_no] = {page_to_replace->pid, page_to_replace->page_no};
        rev_page_table_virtual_memory[{page_to_replace->pid, page_to_replace->page_no}] = page->frame_no;
        virtual_frame_no_to_page[page->frame_no] = page_to_replace;

        page->frame_no = frame_no_to_replace;
        page->where_is_it = 0;

        page_to_replace->frame_no = frame_no;
        page_to_replace->where_is_it = 1;

        // outfile<<"Page "<<which_page<<" of process "<<pid<<" is loaded into frame "<<frame_no<<" of main memory"<<endl;
        fifo_queue.push(page);
        // outfile << "hi" << endl;
    }
}

bool execute_load(int pid, int val, int addr)
{
    int which_page = addr / page_size;
    int offset = addr % page_size;
    // find page of that pid in main memory
    int size = stoi(id_to_instructions[pid][0]);
    if (which_page >= size * 1024 / page_size)
    {
        outfile << "Invalid Memory Address " << addr << " " << "specified for process id " << pid << endl;
        return false;
    }

    if (rev_page_table_main_memory.find({pid, which_page}) != rev_page_table_main_memory.end())
    {
        int frame_no = rev_page_table_main_memory[{pid, which_page}];
        Page *page = frame_no_to_page[frame_no];
        offset_to_value_main[frame_no][offset] = val;
    }
    else
    {
        // find page of that pid in virtual memory
        if (rev_page_table_virtual_memory.find({pid, which_page}) != rev_page_table_virtual_memory.end())
        {
            int frame_no = rev_page_table_virtual_memory[{pid, which_page}];
            Page *page = virtual_frame_no_to_page[frame_no];
            // swap the page to main memory
            swap_to_main_memory(which_page, pid, val, addr, page, offset, frame_no);
            frame_no = rev_page_table_main_memory[{pid, which_page}];
            offset_to_value_main[frame_no][offset] = val;
        }
        else
        {
            outfile << "Invalid Memory Address " << addr << " " << "specified for process id " << pid << endl;
            return false;
        }
    }
    outfile << "Command: load " << val << ", " << addr << "; ";
    outfile << "Result: Value of " << val << " is now stored in addr " << addr << "" << endl;
    return true;
}
bool execute_add(int pid, int addr1, int addr2, int addr3)
{
    int which_page1 = addr1 / page_size;
    int offset1 = addr1 % page_size;
    int which_page2 = addr2 / page_size;
    int offset2 = addr2 % page_size;
    int which_page3 = addr3 / page_size;
    int offset3 = addr3 % page_size;
    int size = stoi(id_to_instructions[pid][0]);

    int val1;
    int val2;
    int result;

    if (addr1 >= size * 1024)
    {
        outfile << "Invalid Memory Address " << addr1 << " " << "specified for process id " << pid << endl;
        return false;
    }
    if (addr2 >= size * 1024)
    {
        outfile << "Invalid Memory Address " << addr2 << " " << "specified for process id " << pid << endl;
        return false;
    }
    if (addr3 >= size * 1024)
    {
        outfile << "Invalid Memory Address " << addr3 << " " << "specified for process id " << pid << endl;
        return false;
    }

    if (rev_page_table_main_memory.find({pid, which_page1}) != rev_page_table_main_memory.end())
    {
        int frame_no = rev_page_table_main_memory[{pid, which_page1}];
        Page *page = frame_no_to_page[frame_no];
        val1 = offset_to_value_main[frame_no][offset1];
    }
    else
    {
        if (rev_page_table_virtual_memory.find({pid, which_page1}) != rev_page_table_virtual_memory.end())
        {
            int frame_no = rev_page_table_virtual_memory[{pid, which_page1}];
            Page *page = virtual_frame_no_to_page[frame_no];
            // swap the page to main memory
            swap_to_main_memory(which_page1, pid, val1, addr1, page, offset1, frame_no);
            frame_no = rev_page_table_main_memory[{pid, which_page1}];
            val1 = offset_to_value_main[frame_no][offset1];
        }
        else
        {
            outfile << "Invalid Memory Address " << addr1 << " " << "specified for process id " << pid << endl;
            return false;
        }
    }

    if (rev_page_table_main_memory.find({pid, which_page2}) != rev_page_table_main_memory.end())
    {
        int frame_no = rev_page_table_main_memory[{pid, which_page2}];
        Page *page = frame_no_to_page[frame_no];
        val2 = offset_to_value_main[frame_no][offset2];
    }
    else
    {
        if (rev_page_table_virtual_memory.find({pid, which_page2}) != rev_page_table_virtual_memory.end())
        {
            int frame_no = rev_page_table_virtual_memory[{pid, which_page2}];
            Page *page = virtual_frame_no_to_page[frame_no];
            // swap the page to main memory
            swap_to_main_memory(which_page2, pid, val2, addr2, page, offset2, frame_no);
            frame_no = rev_page_table_main_memory[{pid, which_page2}];
            val2 = offset_to_value_main[frame_no][offset2];
        }
        else
        {
            outfile << "Invalid Memory Address " << addr2 << " " << "specified for process id " << pid << endl;
            return false;
        }
    }

    result = val1 + val2;

    if (rev_page_table_main_memory.find({pid, which_page3}) != rev_page_table_main_memory.end())
    {
        int frame_no = rev_page_table_main_memory[{pid, which_page3}];
        Page *page = frame_no_to_page[frame_no];
        offset_to_value_main[frame_no][offset3] = result;
    }
    else
    {
        if (rev_page_table_virtual_memory.find({pid, which_page3}) != rev_page_table_virtual_memory.end())
        {
            int frame_no = rev_page_table_virtual_memory[{pid, which_page3}];
            Page *page = virtual_frame_no_to_page[frame_no];
            // swap the page to main memory
            swap_to_main_memory(which_page3, pid, result, addr3, page, offset3, frame_no);
            frame_no = rev_page_table_main_memory[{pid, which_page3}];
            offset_to_value_main[frame_no][offset3] = result;
        }
        else
        {
            outfile << "Invalid Memory Address " << addr3 << " " << "specified for process id " << pid << endl;
            return false;
        }
    }

    outfile << "Command: add " << addr1 << ", " << addr2 << ", " << addr3 << "; ";
    outfile << "Result: Value in addr " << addr1 << " = " << val1 << ", addr " << addr2 << " = " << val2 << ", addr " << addr3 << " = " << result << endl;
    return true;
}

bool execute_sub(int pid, int addr1, int addr2, int addr3)
{
    int which_page1 = addr1 / page_size;
    int offset1 = addr1 % page_size;
    int which_page2 = addr2 / page_size;
    int offset2 = addr2 % page_size;
    int which_page3 = addr3 / page_size;
    int offset3 = addr3 % page_size;
    int size = stoi(id_to_instructions[pid][0]);

    int val1;
    int val2;
    int result;

    if (addr1 >= size * 1024)
    {
        outfile << "Invalid Memory Address " << addr1 << " " << "specified for process id " << pid << endl;
        return false;
    }
    if (addr2 >= size * 1024)
    {
        outfile << "Invalid Memory Address " << addr2 << " " << "specified for process id " << pid << endl;
        return false;
    }
    if (addr3 >= size * 1024)
    {
        outfile << "Invalid Memory Address " << addr3 << " " << "specified for process id " << pid << endl;
        return false;
    }

    if (rev_page_table_main_memory.find({pid, which_page1}) != rev_page_table_main_memory.end())
    {
        int frame_no = rev_page_table_main_memory[{pid, which_page1}];
        Page *page = frame_no_to_page[frame_no];
        val1 = offset_to_value_main[frame_no][offset1];
    }
    else
    {
        if (rev_page_table_virtual_memory.find({pid, which_page1}) != rev_page_table_virtual_memory.end())
        {
            int frame_no = rev_page_table_virtual_memory[{pid, which_page1}];
            Page *page = virtual_frame_no_to_page[frame_no];
            // swap the page to main memory
            swap_to_main_memory(which_page1, pid, val1, addr1, page, offset1, frame_no);
            frame_no = rev_page_table_main_memory[{pid, which_page1}];
            val1 = offset_to_value_main[frame_no][offset1];
        }
        else
        {
            outfile << "Invalid Memory Address " << addr1 << " " << "specified for process id " << pid << endl;
            return false;
        }
    }

    if (rev_page_table_main_memory.find({pid, which_page2}) != rev_page_table_main_memory.end())
    {
        int frame_no = rev_page_table_main_memory[{pid, which_page2}];
        Page *page = frame_no_to_page[frame_no];
        val2 = offset_to_value_main[frame_no][offset2];
    }
    else
    {
        if (rev_page_table_virtual_memory.find({pid, which_page2}) != rev_page_table_virtual_memory.end())
        {
            int frame_no = rev_page_table_virtual_memory[{pid, which_page2}];
            Page *page = virtual_frame_no_to_page[frame_no];
            // swap the page to main memory
            swap_to_main_memory(which_page2, pid, val2, addr2, page, offset2, frame_no);
            frame_no = rev_page_table_main_memory[{pid, which_page2}];
            val2 = offset_to_value_main[frame_no][offset2];
        }
        else
        {
            outfile << "Invalid Memory Address " << addr2 << " " << "specified for process id " << pid << endl;
            return false;
        }
    }

    result = val1 - val2;
    if (rev_page_table_main_memory.find({pid, which_page3}) != rev_page_table_main_memory.end())
    {
        int frame_no = rev_page_table_main_memory[{pid, which_page3}];
        Page *page = frame_no_to_page[frame_no];
        offset_to_value_main[frame_no][offset3] = result;
    }
    else
    {
        if (rev_page_table_virtual_memory.find({pid, which_page3}) != rev_page_table_virtual_memory.end())
        {
            int frame_no = rev_page_table_virtual_memory[{pid, which_page3}];
            Page *page = virtual_frame_no_to_page[frame_no];
            // swap the page to main memory
            swap_to_main_memory(which_page3, pid, result, addr3, page, offset3, frame_no);
            frame_no = rev_page_table_main_memory[{pid, which_page3}];
            offset_to_value_main[frame_no][offset3] = result;
        }
        else
        {
            outfile << "Invalid Memory Address " << addr3 << " " << "specified for process id " << pid << endl;
            return false;
        }
    }
    outfile << "Command: sub " << addr1 << ", " << addr2 << ", " << addr3 << "; ";
    outfile << "Result: Value in addr " << addr1 << " = " << val1 << ", addr " << addr2 << " = " << val2 << ", addr " << addr3 << " = " << result << endl;
    return true;
}

bool print(int pid, int addr)
{
    int which_page = addr / page_size;
    int offset = addr % page_size;

    int size = stoi(id_to_instructions[pid][0]);
    if (which_page >= size * 1024 / page_size)
    {
        outfile << "Invalid Memory Address " << addr << " " << "specified for process id " << pid << endl;
        return false;
    }
    int val;
    if (rev_page_table_main_memory.find({pid, which_page}) != rev_page_table_main_memory.end())
    {
        int frame_no = rev_page_table_main_memory[{pid, which_page}];
        Page *page = frame_no_to_page[frame_no];
        val = offset_to_value_main[frame_no][offset];
        // outfile<<"kuch nahi hua"<<endl;
    }
    else
    {
        // find page of that pid in virtual memory
        if (rev_page_table_virtual_memory.find({pid, which_page}) != rev_page_table_virtual_memory.end())
        {
            int frame_no = rev_page_table_virtual_memory[{pid, which_page}];
            Page *page = virtual_frame_no_to_page[frame_no];
            // swap the page to main memory
            swap_to_main_memory(which_page, pid, val, addr, page, offset, frame_no);
            frame_no = rev_page_table_main_memory[{pid, which_page}];
            val = offset_to_value_main[frame_no][offset];
        }
        else
        {
            outfile << "Invalid Memory Address " << addr << " " << "specified for process id " << pid << endl;
            return false;
        }
    }
    outfile << "Command: print " << addr << "; ";
    outfile << "Result: Value in addr " << addr << " = " << val << endl;
    return true;
}

void execute(vector<string> instructions, int pid)
{
    int size = stoi(instructions[0]);

    for (int i = 1; i < instructions.size(); i++)
    {
        // parse the instruction
        // print queue

        string instruction = instructions[i];
        vector<string> instr_parts;
        string instr_part;
        // for (int j = 0; j < instruction.size(); j++)
        // {
        //     if (instruction[j] == ' ')
        //     {

        //         if (instr_part.size() > 0)
        //         {
        //             instr_parts.push_back(instr_part);
        //             instr_part = "";
        //         }
        //     }
        //     else
        //     {
        //         if (instruction[j] == ',')
        //         {
        //             instr_parts.push_back(instr_part);
        //             instr_part = "";
        //         }
        //         else
        //         {
        //             instr_part += instruction[j];
        //         }
        //     }
        // }
        // instr_parts.push_back(instr_part);

        istringstream ss(instruction);

        ss >> instr_part;
        instr_parts.push_back(instr_part);

        // instr_parts.push_back(instr_part);
        if (instr_parts[0] == "load")
        {
            char c;
            int val;
            int addr;
            ss >> val >> c >> addr;
            if (!execute_load(pid, val, addr))
            {
                return;
            }
        }
        else if (instr_parts[0] == "add")
        {
            char c;
            int addr1;
            int addr2;
            int addr3;
            ss >> addr1 >> c >> addr2 >> c >> addr3;
            if (!execute_add(pid, addr1, addr2, addr3))
            {
                return;
            }
        }
        else if (instr_parts[0] == "sub")
        {
            char c;
            int addr1;
            int addr2;
            int addr3;
            ss >> addr1 >> c >> addr2 >> c >> addr3;
            if (!execute_sub(pid, addr1, addr2, addr3))
            {
                return;
            }
        }
        else if (instr_parts[0] == "print")
        {
            int addr;
            ss >> addr;
            if (!print(pid, addr))
            {
                return;
            }
        }

        // for(int i=0;i<fifo_queue.size();i++){
        //     Page *page = fifo_queue.front();
        //     fifo_queue.pop();
        //     outfile<<page->pid<<" "<<page->where_is_it<<" "<<page->frame_no<<" "<<page->page_no<<endl;

        //     fifo_queue.push(page);
        // }
        // outfile<<"printed queue once"<<endl;
    }
}

bool check_if_file_exists(string filename)
{
    ifstream infile;
    infile.open(filename);
    if (infile)
    {
        infile.close();
        return true;
    }
    else
    {
        return false;
    }
}

int main(int argc, char *argv[])
{
    int opt;
    string input_file;
    string output_file;
    while ((opt = getopt(argc, argv, "M:V:P:i:o:")) != -1)
    {
        switch (opt)
        {
        case 'M':
            memory_size = atoi(optarg);
            break;
        case 'V':
            virtual_memory_size = atoi(optarg);
            break;
        case 'P':
            page_size = atoi(optarg);
            break;
        case 'i':
            input_file = (string)strdup(optarg);
            break;
        case 'o':
            output_file = (string)strdup(optarg);
            break;
        default:
            fprintf(stderr, "wrong format\n");
            exit(1);
        }
    }
    no_of_virpages = virtual_memory_size * 1024 / page_size;
    no_of_mempages = memory_size * 1024 / page_size;

    memory_size = memory_size * 1024;
    virtual_memory_size = virtual_memory_size * 1024;

    infile.open(input_file);
    outfile.open(output_file);

    for (int i = 0; i < no_of_mempages; i++)
    {
        free_slots_main_memory.insert(i);
    }
    for (int i = 0; i < no_of_virpages; i++)
    {
        free_slots_virtual_memory.insert(i);
    }

    vector<string> linelems;
    string linelem;
    string temp;
    while (getline(infile, linelem))
    {
        string temp;
        istringstream ss(linelem);
        while (ss >> temp)
        {
            linelems.push_back(temp);
        }
        // outfile << "debug" << endl;
        // for (int i = 0; i < linelems.size(); i++)
        // {
        //     outfile << linelems[i] << endl;
        // }

        if (linelems[0] == "load")
        {
            for (int i = 1; i < linelems.size(); i++)
            {
                if (check_if_file_exists(linelems[i]))
                {
                    ifstream tempfile(linelems[i]);
                    string tempsize;
                    tempfile >> tempsize;
                    int size = stoi(tempsize);
                    // cout<<"size is "<<size<<endl;
                    int total_rem_memory = memory_size - memory + virtual_memory_size - virtual_memory;
                    // cout<<"remaining memory is "<<total_rem_memory<<endl;
                    if (size * 1024 > total_rem_memory)
                    {
                        outfile << linelems[i] << " could not be loaded - memory is full" << endl;
                    }
                    else
                    {
                        // fill the memory followed by virtual memory in the free slots
                        ++global_pid;
                        int mempagesadded = 0;
                        int virpagesadded = 0;
                        for (int i = 0; i < size * 1024 / page_size; i++)
                        {
                            if (free_slots_main_memory.size() > 0)
                            {
                                int frame_no = *free_slots_main_memory.begin();
                                free_slots_main_memory.erase(free_slots_main_memory.begin());
                                page_table_main_memory[frame_no] = {global_pid, i};
                                rev_page_table_main_memory[{global_pid, i}] = frame_no;
                                Page *new_page = new Page(global_pid, 0, frame_no, i);
                                frame_no_to_page[frame_no] = new_page;
                                fifo_queue.push(new_page);
                                mempagesadded++;
                            }
                            else
                            {
                                int frame_no = *free_slots_virtual_memory.begin();
                                free_slots_virtual_memory.erase(free_slots_virtual_memory.begin());
                                page_table_virtual_memory[frame_no] = {global_pid, i};
                                rev_page_table_virtual_memory[{global_pid, i}] = frame_no;
                                Page *new_page = new Page(global_pid, 1, frame_no, i);
                                virtual_frame_no_to_page[frame_no] = new_page;
                                virpagesadded++;
                            }
                        }
                        memory += mempagesadded * page_size;
                        virtual_memory += virpagesadded * page_size;
                        outfile << linelems[i] << " is loaded and is assigned process id " << global_pid << endl;
                        valid_pids.insert(global_pid);
                        id_file[global_pid] = linelems[i];
                        file_id[linelems[i]] = global_pid;
                        id_to_instructions[global_pid] = vector<string>();
                        id_to_instructions[global_pid].push_back(to_string(size));
                        while (getline(tempfile, tempsize))
                        {
                            id_to_instructions[global_pid].push_back(tempsize);
                        }
                    }
                }
                else
                {
                    outfile << linelems[i] << " could not be loaded - file does not exist" << endl;
                }
            }
        }
        else if (linelems[0] == "run")
        {
            int pid = stoi(linelems[1]);
            if (valid_pids.find(pid) == valid_pids.end())
            {
                outfile << "Invalid PID " << pid << endl;
            }
            else
            {
                execute(id_to_instructions[pid], pid);
            }
        }
        else if (linelems[0] == "kill")
        {
            int pid = stoi(linelems[1]);
            if (valid_pids.find(pid) == valid_pids.end())
            {
                outfile << "Invalid PID " << pid << endl;
            }
            else
            {
                // remove the pages from memory
                // dont remove values stored in the locations
                for (int i = 0; i < no_of_mempages; i++)
                {
                    if (page_table_main_memory.find(i) != page_table_main_memory.end())
                    {
                        if (page_table_main_memory[i].first == pid)
                        {
                            free_slots_main_memory.insert(i);
                            rev_page_table_main_memory.erase({pid, page_table_main_memory[i].second});
                            page_table_main_memory.erase(i);
                            frame_no_to_page.erase(i);
                            memory -= page_size;
                        }
                    }
                }
                for (int i = 0; i < no_of_virpages; i++)
                {
                    if (page_table_virtual_memory.find(i) != page_table_virtual_memory.end())
                    {
                        if (page_table_virtual_memory[i].first == pid)
                        {
                            free_slots_virtual_memory.insert(i);
                            rev_page_table_virtual_memory.erase({pid, page_table_virtual_memory[i].second});
                            page_table_virtual_memory.erase(i);
                            Page *to_delete = virtual_frame_no_to_page[i];
                            virtual_frame_no_to_page.erase(i);
                            delete to_delete;
                            virtual_memory -= page_size;
                        }
                    }
                }
                // update queue and free pages
                queue<Page *> temp;
                while (!fifo_queue.empty())
                {
                    Page *page = fifo_queue.front();
                    fifo_queue.pop();
                    if (page->pid != pid)
                    {
                        temp.push(page);
                    }
                    else
                    {
                        delete page;
                    }
                }

                file_id.erase(id_file[pid]);
                id_file.erase(pid);
                valid_pids.erase(pid);
                id_to_instructions.erase(pid);
                fifo_queue = temp;
                outfile << "killed " << pid << endl;
            }
        }
        else if (linelems[0] == "listpr")
        {
            set<int> pids;
            for (int i = 0; i < no_of_mempages; i++)
            {
                if (page_table_main_memory.find(i) != page_table_main_memory.end())
                {
                    pids.insert(page_table_main_memory[i].first);
                }
            }
            for (int i = 0; i < no_of_virpages; i++)
            {
                if (page_table_virtual_memory.find(i) != page_table_virtual_memory.end())
                {
                    pids.insert(page_table_virtual_memory[i].first);
                }
            }
            for (auto it = pids.begin(); it != pids.end(); it++)
            {
                outfile << *it << " ";
            }
            outfile << endl;
        }
        else if (linelems[0] == "pte")
        {
            int pid = stoi(linelems[1]);
            if (valid_pids.find(pid) == valid_pids.end())
            {
                outfile << "Invalid PID " << pid << endl;
            }
            else
            {
                int size = stoi(id_to_instructions[pid][0]);
                string outputfile = linelems[2];
                ofstream outfilepte(outputfile, ios::app);
                time_t curtime = time(NULL);
                tm *curtime_tm = localtime(&curtime);
                outfilepte << asctime(curtime_tm);
                for (int i = 0; i < size * 1024 / page_size; i++)
                {
                    if (rev_page_table_main_memory.find({pid, i}) != rev_page_table_main_memory.end())
                    {
                        outfilepte << i << " " << rev_page_table_main_memory[{pid, i}] << " " << 1 << endl;
                    }
                    else if (rev_page_table_virtual_memory.find({pid, i}) != rev_page_table_virtual_memory.end())
                    {
                        outfilepte << i << " " << rev_page_table_virtual_memory[{pid, i}] << " " << 0 << endl;
                    }
                    else
                    {
                        outfilepte << i << " -1 -1" << endl;
                    }
                }
            }
        }
        else if (linelems[0] == "pteall")
        {
            string outputfile = linelems[1];
            ofstream outfilepte(outputfile, ios::app);
            // outfile << "outputfile: " << outputfile << endl;
            time_t curtime = time(NULL);
            tm *curtime_tm = localtime(&curtime);
            outfilepte << asctime(curtime_tm);
            // outfilepte<<"noof pid"<<global_pid<<endl;
            for (int i = 1; i <= global_pid; i++)
            {
                if (valid_pids.find(i) == valid_pids.end())
                {
                    continue;
                }
                int size = stoi(id_to_instructions[i][0]);

                for (int j = 0; j < size * 1024 / page_size; j++)
                {
                    if (rev_page_table_main_memory.find({i, j}) != rev_page_table_main_memory.end())
                    {
                        outfilepte << i << " " << j << " " << rev_page_table_main_memory[{i, j}] << " " << 1 << endl;
                    }
                    else if (rev_page_table_virtual_memory.find({i, j}) != rev_page_table_virtual_memory.end())
                    {
                        outfilepte << i << " " << j << " " << rev_page_table_virtual_memory[{i, j}] << " " << 0 << endl;
                    }
                    else
                    {
                        outfilepte << i << " " << j << " -1 -1" << endl;
                    }
                }
            }
        }
        else if (linelems[0] == "print")
        {
            int memloc = stoi(linelems[1]);
            int len = stoi(linelems[2]);

            for (int i = memloc; (i < memloc + len); i++)
            {
                if (i >= memory_size)
                {
                    outfile << "Invalid Memory Address" << endl;
                    break;
                }
                int which_page = i / page_size;
                int offset = i % page_size;
                int val;
                val = offset_to_value_main[which_page][offset];
                outfile << "Value of " << i << ": " << val << endl;
            }
        }
        else if (linelems[0] == "exit")
        {
            // free everything
            for (int i = 0; i < no_of_mempages; i++)
            {
                if (page_table_main_memory.find(i) != page_table_main_memory.end())
                {
                    rev_page_table_main_memory.erase({page_table_main_memory[i].first, page_table_main_memory[i].second});
                    page_table_main_memory.erase(i);
                    delete frame_no_to_page[i];
                    frame_no_to_page.erase(i);
                }
            }
            for (int i = 0; i < no_of_virpages; i++)
            {
                if (page_table_virtual_memory.find(i) != page_table_virtual_memory.end())
                {
                    rev_page_table_virtual_memory.erase({page_table_virtual_memory[i].first, page_table_virtual_memory[i].second});
                    page_table_virtual_memory.erase(i);
                    delete virtual_frame_no_to_page[i];
                    virtual_frame_no_to_page.erase(i);
                }
            }
        }
        // outfile << "command executed" << linelems[0] << endl
        //      << endl;
        linelems.clear();
    }
    
    for (int i = 0; i < no_of_mempages; i++)
    {
        if (page_table_main_memory.find(i) != page_table_main_memory.end())
        {
            rev_page_table_main_memory.erase({page_table_main_memory[i].first, page_table_main_memory[i].second});
            page_table_main_memory.erase(i);
            delete frame_no_to_page[i];
            frame_no_to_page.erase(i);
        }
    }
    for (int i = 0; i < no_of_virpages; i++)
    {
        if (page_table_virtual_memory.find(i) != page_table_virtual_memory.end())
        {
            rev_page_table_virtual_memory.erase({page_table_virtual_memory[i].first, page_table_virtual_memory[i].second});
            page_table_virtual_memory.erase(i);
            delete virtual_frame_no_to_page[i];
            virtual_frame_no_to_page.erase(i);
        }
    }
}

// 10 512 5